// JS pronto per funzioni future.
